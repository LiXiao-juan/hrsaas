<template>
  <div style="margin: 0 10px">
    <svg-icon iconClass="fullscreen" className="fullscreen" />
  </div>
</template>

<script>
export default {
  name: 'Fullscreen',
  components: {},
  data() {
    return {}
  },
  created() {},
  methods: {}
}
</script>

<style scoped lang="scss">
.fullscreen {
    color: #fff;
    
}
</style>
